#!/usr/bin/env python3
"""US-LA one-click primary node: VLESS PQ + REALITY + TCP Vision on TCP 443.
Command: oneclick (no prompts); rollback is available.
Requires only Python 3 stdlib and installed Mihomo 1.19.33.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import secrets
import shutil
import socket
import stat
import subprocess
import sys
import tempfile
import time
import uuid

CONFIG = Path('/etc/mihomo/config.yaml')
BIN = Path('/usr/local/bin/mihomo')
STATE = Path('/etc/mihomo/us-la-rollout/01')
BIND_DROPIN = Path('/etc/systemd/system/mihomo.service.d/90-dmit-us-la-bind443.conf')
BIND_DROPIN_TEXT = '[Service]\nAmbientCapabilities=CAP_NET_BIND_SERVICE\n'
SERVICE = 'mihomo'
NEW_PORT = 443
OLD_PORT = 18443
DOMAIN = 'tt.waylan.org'
REGION = 'US-LA'
NODE = 'US-LA-VLESS-PQ'

class Halt(Exception):
    pass

def run(cmd, check=True, timeout=35, user=None, capture=True):
    kw = {}
    if user is not None:
        account = pwd.getpwnam(user)
        def demote():
            os.initgroups(user, account.pw_gid)
            os.setgid(account.pw_gid)
            os.setuid(account.pw_uid)
        kw['preexec_fn'] = demote
    p = subprocess.run(cmd, text=True, capture_output=capture, timeout=timeout, **kw)
    if check and p.returncode:
        raise Halt('Command failed: {}\n{}'.format(' '.join(map(str, cmd)), (p.stderr or p.stdout or '')[-3000:]))
    return p

def check_root():
    if os.geteuid() != 0:
        raise Halt('Run with sudo/root.')
    if not BIN.is_file() or not CONFIG.is_file():
        raise Halt('Expected installed Mihomo and /etc/mihomo/config.yaml; neither will be installed or overwritten blindly.')

def identity():
    user = run(['systemctl', 'show', SERVICE, '-p', 'User', '--value']).stdout.strip()
    if not user or user == 'root':
        raise Halt('Service must have a non-root User= in systemd; refusing to alter service permissions.')
    entry = pwd.getpwnam(user)
    return user, entry.pw_gid

def split_listeners(text):
    all_lines = text.splitlines(keepends=True)
    pos = [i for i, line in enumerate(all_lines) if re.match(r'^listeners:\s*(?:#.*)?$', line.rstrip('\n'))]
    if len(pos) != 1:
        raise Halt('Require exactly one top-level listeners: key (multiline YAML). Refusing risky automatic rewriting.')
    start = pos[0]
    end = len(all_lines)
    for i in range(start + 1, len(all_lines)):
        l = all_lines[i]
        if re.match(r'^[A-Za-z_][A-Za-z_0-9-]*\s*:', l):
            end = i
            break
    return ''.join(all_lines[:start]), ''.join(all_lines[start:end]), ''.join(all_lines[end:])

def parse_existing():
    raw = CONFIG.read_text()
    pre, old, post = split_listeners(raw)
    types = re.findall(r'(?m)^\s+-?\s*type:\s*["\']?([a-zA-Z0-9_-]+)', old)
    if types != ['vless']:
        raise Halt('Expected exactly one VLESS listener and no other listener entries; found {}. Refusing to delete unknown nodes automatically.'.format(types))
    if not re.search(r'(?m)^\s+reality-config:\s*$', old):
        raise Halt('Existing VLESS listener lacks reality-config; do not guess SNI and destination.')
    if not re.search(r'(?m)^\s+decryption:\s*["\']?mlkem768x25519plus\.', old):
        raise Halt('Expected existing working ML-KEM VLESS decryption; please inspect actual config first.')
    dest = re.search(r'(?m)^\s+dest:\s*["\']?([^\s"\']+)', old)
    name = re.search(r'(?m)^\s+server-names:\s*\n\s+-\s*["\']?([^\s"\']+)', old)
    if not dest or not name:
        raise Halt('Cannot safely extract REALITY dest and server-names from the existing config.')
    dest = dest.group(1)
    sni = name.group(1)
    if not re.fullmatch(r'[A-Za-z0-9.-]+:\d{1,5}', dest) or not re.fullmatch(r'[A-Za-z0-9.-]+', sni):
        raise Halt('Unexpected REALITY dest or server name; refusing unsafe templating.')
    return raw, pre, old, post, dest, sni, types

def sha(b):
    return hashlib.sha256(b if isinstance(b, bytes) else b.encode()).hexdigest()

def port_open(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(('0.0.0.0', port))
            return False
        except OSError:
            return True

def field(output, key):
    m = re.search(r'(?mi)^\s*' + re.escape(key) + r':\s*(\S+)\s*$', output)
    if not m:
        raise Halt('mihomo generate did not return expected {} field; output NOT logged because it may contain secrets.'.format(key))
    v = m.group(1)
    if not re.fullmatch(r'[A-Za-z0-9_+\-/=]+', v):
        raise Halt('Unexpected characters in {}.'.format(key))
    return v

def quote(v):
    return json.dumps(v, ensure_ascii=True)

def atomic_secret(path, content, group=None, mode=0o600):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.vision-', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w') as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        if group is not None:
            os.chown(temp, 0, group)
        os.chmod(temp, mode)
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)

def validate(path, user):
    home = '/var/lib/mihomo'
    if not Path(home).is_dir():
        raise Halt('Expected Mihomo HOME directory /var/lib/mihomo, refusing to guess.')
    p = run([str(BIN), '-t', '-d', home, '-f', str(path)], timeout=90, user=user, check=False)
    if p.returncode:
        raise Halt('Mihomo config verification failed:\n' + (p.stderr + '\n' + p.stdout)[-4000:])

def ensure_not_modified(meta):
    if sha(CONFIG.read_bytes()) != meta['original_sha256']:
        raise Halt('Live config changed after preparation. Refusing to overwrite newer edits.')

def is_443_unprivileged():
    path = Path('/proc/sys/net/ipv4/ip_unprivileged_port_start')
    try:
        return int(path.read_text().strip()) <= 443
    except (OSError, ValueError):
        return False

def systemd_has_bind_cap():
    p = run(['systemctl', 'show', SERVICE, '-p', 'AmbientCapabilities', '--value'], check=False)
    return 'CAP_NET_BIND_SERVICE' in p.stdout.upper().split()

def needs_bind_cap():
    return not (is_443_unprivileged() or systemd_has_bind_cap())

def permit443():
    check_root()
    meta = get_meta()
    if meta['state'] != 'prepared':
        raise Halt('Run prepare first and only grant capabilities before apply.')
    if not needs_bind_cap():
        print('TCP 443 can already be bound by the service; no systemd changes necessary.')
        return
    if BIND_DROPIN.exists():
        raise Halt('Our reserved systemd override file already exists. Inspect it rather than overwriting.')
    BIND_DROPIN.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(str(BIND_DROPIN), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    try:
        with os.fdopen(fd, 'w') as f:
            f.write(BIND_DROPIN_TEXT)
            f.flush()
            os.fsync(f.fileno())
        run(['systemctl', 'daemon-reload'])
        meta['bind443_dropin_created'] = True
        atomic_secret(STATE / 'metadata.json', json.dumps(meta, indent=2))
    except Exception:
        if BIND_DROPIN.exists() and BIND_DROPIN.read_text() == BIND_DROPIN_TEXT:
            BIND_DROPIN.unlink()
            run(['systemctl', 'daemon-reload'], check=False)
        raise
    print('Applied minimal systemd override to allow non-root Mihomo to bind TCP 443.')
    print('The running Mihomo has NOT been restarted; capability becomes active on apply.')

def undo_bind443_override(meta):
    if not meta.get('bind443_dropin_created'):
        return
    if not BIND_DROPIN.exists():
        return  # May already have been removed by an automatic apply rollback.
    if not BIND_DROPIN.is_file() or BIND_DROPIN.read_text() != BIND_DROPIN_TEXT:
        raise Halt('Systemd override changed after creation; refusing to delete it automatically.')
    BIND_DROPIN.unlink()
    run(['systemctl', 'daemon-reload'])

def label(v):
    v = v.strip()
    if not re.fullmatch(r'[A-Z]{2}-[A-Za-z][A-Za-z0-9]{1,24}', v):
        raise Halt('Use a verified region label, e.g. US-LosAngeles, JP-Tokyo, HK-HongKong (do not guess).')
    return v

def preflight():
    check_root()
    user, gid = identity()
    version = run([str(BIN), '-v']).stdout.strip().splitlines()[0]
    if '1.19.33' not in version:
        raise Halt('Expected Mihomo v1.19.33, found: {}'.format(version))
    raw, _, old, _, dest, sni, types = parse_existing()
    print('Mihomo: ' + version)
    print('Systemd user: {}'.format(user))
    print('Current listener types: {}'.format(', '.join(types)))
    print('Existing REALITY SNI: {}, dest: {}'.format(sni, dest))
    print('Ports: old TCP {} {}; target TCP {} {}'.format(OLD_PORT, 'occupied' if port_open(OLD_PORT) else 'free', NEW_PORT, 'occupied' if port_open(NEW_PORT) else 'free'))
    print('Cloudflare DNS-only name to use: {}'.format(DOMAIN))
    print('Low-port binding: {}'.format('already permitted' if not needs_bind_cap() else 'will require explicit permit443 step (systemd drop-in)'))
    if shutil.which('firewall-cmd'):
        fw = run(['systemctl', 'is-active', 'firewalld'], check=False).stdout.strip()
        if fw == 'active':
            permitted = (run(['firewall-cmd', '--query-port={}/tcp'.format(NEW_PORT)], check=False).returncode == 0 or run(['firewall-cmd', '--query-service=https'], check=False).returncode == 0)
            print('firewalld TCP {}: {}'.format(NEW_PORT, 'ALLOWED' if permitted else 'NOT OPEN; add explicitly if needed'))
    try:
        ips = sorted(set(x[4][0] for x in socket.getaddrinfo(DOMAIN, None, family=socket.AF_INET)))
        if not ips:
            raise Halt('DNS has no IPv4 A record for {}. Refusing cutover.'.format(DOMAIN))
        print('DNS A records: ' + ', '.join(ips))
    except OSError as exc:
        raise Halt('DNS lookup failed for {} ({}). Refusing cutover.'.format(DOMAIN, exc))
    print('Live config SHA256: {}'.format(sha(raw)))
    return user, gid, raw, old, dest, sni, types

def prepare(args):
    user, gid, raw, old, dest, sni, types = preflight()
    if port_open(NEW_PORT):
        raise Halt('Target TCP 443 is already occupied; will not disrupt existing service.')
    if STATE.exists() and (STATE / 'metadata.json').exists():
        raise Halt('A prepared rollout already exists. Apply/rollback it first; do not overwrite its backup.')
    region = label(REGION)
    node = 'US-LA-VLESS-PQ'
    reality = run([str(BIN), 'generate', 'reality-keypair']).stdout
    mlkem = run([str(BIN), 'generate', 'vless-mlkem768']).stdout
    x25519 = run([str(BIN), 'generate', 'vless-x25519']).stdout
    rpriv, rpub = field(reality, 'PrivateKey'), field(reality, 'PublicKey')
    pqseed, pqclient = field(mlkem, 'Seed'), field(mlkem, 'Client')
    xpriv, xpass = field(x25519, 'PrivateKey'), field(x25519, 'Password')
    sid = secrets.token_hex(8)
    user_uuid = str(uuid.uuid4())
    decrypt = 'mlkem768x25519plus.native.0s.{}.{}'.format(xpriv, pqseed)
    encrypt = 'mlkem768x25519plus.native.1rtt.{}.{}'.format(xpass, pqclient)
    new_listener = '''listeners:\n  - name: {node}\n    type: vless\n    listen: 0.0.0.0\n    port: {port}\n    users:\n      - username: primary\n        uuid: {uuid}\n        flow: xtls-rprx-vision\n    decryption: {dec}\n    reality-config:\n      dest: {dest}\n      private-key: {rpriv}\n      short-id:\n        - {sid}\n      server-names:\n        - {sni}\n'''.format(node=quote(node), port=NEW_PORT, uuid=quote(user_uuid), dec=quote(decrypt), dest=quote(dest), rpriv=quote(rpriv), sid=quote(sid), sni=quote(sni))
    pre, _, post = split_listeners(raw)
    candidate = pre + new_listener + post
    node_fields = '''  - name: {node}\n    type: vless\n    server: {domain}\n    port: {port}\n    uuid: {uuid}\n    network: tcp\n    tls: true\n    sni: {sni}\n    client-fingerprint: chrome\n    flow: xtls-rprx-vision\n    encryption: {enc}\n    udp: true\n    packet-encoding: xudp\n    reality-opts:\n      public-key: {rpub}\n      short-id: {sid}\n'''.format(node=quote(node), domain=quote(DOMAIN), port=NEW_PORT, uuid=quote(user_uuid), sni=quote(sni), enc=quote(encrypt), rpub=quote(rpub), sid=quote(sid))
    client = 'proxies:\n' + node_fields
    standalone = client + '''proxy-groups:\n  - name: Proxy\n    type: select\n    proxies:\n      - {node}\n      - DIRECT\nrules:\n  - MATCH,Proxy\n'''.format(node=quote(node))
    STATE.mkdir(mode=0o710, parents=True, exist_ok=False)
    os.chmod(STATE.parent, 0o711)  # service can traverse; cannot list root-only rollouts
    # The non-root Mihomo process must be able to traverse STATE to read candidate.yaml.
    # Other generated secrets remain 0600 and cannot be read by the service.
    os.chown(STATE, 0, gid)
    os.chmod(STATE, 0o710)
    atomic_secret(STATE / 'previous-config.yaml', raw)
    atomic_secret(STATE / 'candidate.yaml', candidate, group=gid, mode=0o640)
    atomic_secret(STATE / 'stash-node.yaml', client)
    atomic_secret(STATE / 'stash-profile.yaml', standalone)
    meta = dict(node_name=node, original_sha256=sha(raw), candidate_sha256=sha(candidate), port=NEW_PORT, old_port=OLD_PORT, sni=sni, dest=dest, created_utc=int(time.time()), user=user, gid=gid, state='prepared')
    atomic_secret(STATE / 'metadata.json', json.dumps(meta, indent=2))
    try:
        validate(STATE / 'candidate.yaml', user)
    except Exception:
        print('Candidate failed validation; current running config remains unchanged.')
        raise
    print('\nPREPARED, VERIFIED. No live changes yet.')
    print('New node: {}'.format(node))
    print('Candidate: {}'.format(STATE / 'candidate.yaml'))
    print('Stash full profile: {}'.format(STATE / 'stash-profile.yaml'))
    print('Stash proxies snippet: {}'.format(STATE / 'stash-node.yaml'))
    print('Next: if preflight says low-port capability required, run permit443; then run apply.')

def get_meta():
    if not (STATE / 'metadata.json').exists():
        raise Halt('No prepared rollout; run prepare first.')
    return json.loads((STATE / 'metadata.json').read_text())

def restore_from_backup(user, gid, meta=None):
    content = (STATE / 'previous-config.yaml').read_text()
    atomic_secret(CONFIG, content, group=gid, mode=0o640)
    if meta:
        undo_bind443_override(meta)
    p = run(['systemctl', 'restart', SERVICE], check=False, timeout=30)
    if p.returncode:
        raise Halt('Rollback wrote old config but service restart failed: {}'.format(p.stderr))

def apply():
    check_root()
    meta = get_meta()
    user, gid = identity()
    if meta['state'] != 'prepared':
        raise Halt('State is not prepared; refusing repeated application.')
    ensure_not_modified(meta)
    if port_open(NEW_PORT):
        raise Halt('Target TCP port already in use; refusing to restart.')
    if needs_bind_cap():
        raise Halt('Non-root Mihomo lacks permission for TCP 443. Run the explicit permit443 command first.')
    candidate = STATE / 'candidate.yaml'
    if sha(candidate.read_bytes()) != meta['candidate_sha256']:
        raise Halt('Candidate config has changed; aborting.')
    validate(candidate, user)
    # Install config atomically, with a nonroot service-readable group.
    atomic_secret(CONFIG, candidate.read_text(), group=gid, mode=0o640)
    try:
        run(['systemctl', 'restart', SERVICE], timeout=30)
        time.sleep(1.5)
        active = run(['systemctl', 'is-active', SERVICE], check=False).stdout.strip()
        if active != 'active' or not port_open(NEW_PORT):
            raise Halt('Service did not become active and listen on TCP {}'.format(NEW_PORT))
    except Exception as exc:
        print('APPLY FAILED; automatically restoring original Mihomo config...')
        restore_from_backup(user, gid, meta)
        raise Halt('Original configuration restored. Cause: {}'.format(exc))
    meta['state'] = 'applied'
    atomic_secret(STATE / 'metadata.json', json.dumps(meta, indent=2))
    print('APPLIED: {} on TCP {}'.format(meta['node_name'], NEW_PORT))
    print('Old XHTTP listener is absent from the new listeners section (backup retained).')
    print('Run check and then test in Stash; if it fails, run rollback.')

def check():
    check_root()
    meta = get_meta()
    user, gid = identity()
    print('Node: {}'.format(meta['node_name']))
    print('Rollout state: {}'.format(meta['state']))
    print('Service status: {}'.format(run(['systemctl', 'is-active', SERVICE], check=False).stdout.strip()))
    print('TCP {} listener: {}'.format(NEW_PORT, 'LISTENING' if port_open(NEW_PORT) else 'NOT LISTENING'))
    print('TCP {} old port: {}'.format(OLD_PORT, 'occupied' if port_open(OLD_PORT) else 'not listening'))
    print('Config matches candidate: {}'.format('YES' if sha(CONFIG.read_bytes()) == meta['candidate_sha256'] else 'NO'))
    if meta['state'] == 'applied':
        try:
            validate(CONFIG, user)
            print('Mihomo config check: PASS')
        except Exception as exc:
            print('Mihomo config check: FAIL: {}'.format(exc))
    else:
        print('Mihomo candidate pending apply.')
    print('Stash client profile (secret file): {}'.format(STATE / 'stash-profile.yaml'))
    print('Stash node snippet (secret file): {}'.format(STATE / 'stash-node.yaml'))
    print('Note: these checks DO NOT prove public Stash connectivity or firewall reachability.')

def probe():
    """End-to-end LOCAL VLESS handshake using Mihomo as an ephemeral client.
    Does not prove external Internet / Stash connectivity.
    """
    check_root()
    if not shutil.which('curl'):
        raise Halt('curl not installed; no packages will be added automatically.')
    meta = get_meta()
    if meta['state'] != 'applied':
        raise Halt('Apply the new listener before running probe.')
    user, gid = identity()
    if not port_open(NEW_PORT):
        raise Halt('VLESS TCP port not listening; cannot test handshake.')
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(('127.0.0.1', 0))
        socks_port = sock.getsockname()[1]
    snippet = (STATE / 'stash-node.yaml').read_text()
    # Use exactly the freshly generated REALITY+Encryption parameters, but
    # connect to the local listener, thus separating protocol from public reachability.
    snippet = snippet.replace('server: ' + quote(DOMAIN), 'server: "127.0.0.1"', 1)
    # Stash calls this field sni; Mihomo's outbound config names it servername.
    snippet = snippet.replace('    sni: ', '    servername: ', 1)
    node = quote(meta['node_name'])
    payload = ('socks-port: {}\nallow-lan: false\nlog-level: warning\n'.format(socks_port)
        + snippet
        + 'proxy-groups:\n  - name: Check\n    type: select\n    proxies:\n      - {}\nrules:\n  - MATCH,Check\n'.format(node))
    with tempfile.TemporaryDirectory(prefix='vision-local-', dir='/var/lib/mihomo') as tmpdir:
        os.chown(tmpdir, pwd.getpwnam(user).pw_uid, gid)
        os.chmod(tmpdir, 0o700)
        cfg = Path(tmpdir) / 'probe.yaml'
        cfg.write_text(payload)
        os.chown(cfg, pwd.getpwnam(user).pw_uid, gid)
        os.chmod(cfg, 0o600)
        subprocess_env = os.environ.copy()
        subprocess_env['HOME'] = '/var/lib/mihomo'
        proc = subprocess.Popen(
            [str(BIN), '-d', tmpdir, '-f', str(cfg)],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            env=subprocess_env,
            preexec_fn=lambda: (os.initgroups(user, gid), os.setgid(gid), os.setuid(pwd.getpwnam(user).pw_uid))
        )
        try:
            for _ in range(40):
                if proc.poll() is not None:
                    raise Halt('Temporary Mihomo client exited before SOCKS socket became available.')
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(0.2)
                    if s.connect_ex(('127.0.0.1', socks_port)) == 0:
                        break
                time.sleep(0.2)
            else:
                raise Halt('Temporary SOCKS listener did not start.')
            result = run(['curl', '--max-time', '22', '--retry', '0', '-sS', '-o', '/dev/null',
                          '-w', '%{http_code}', '--socks5-hostname', '127.0.0.1:{}'.format(socks_port),
                          'https://example.com/'], timeout=28, check=False)
            print('End-to-end LOCAL proxy probe: curl exit {}, HTTP {}, detail: {}'.format(
                result.returncode, result.stdout.strip(), result.stderr.strip()[-450:]))
            if result.returncode:
                raise Halt('Local end-to-end test failed. Diagnose before using Stash; do not assume remote UDP/TCP issues.')
            print('PASS: local Mihomo client -> VLESS PQ + REALITY + Vision server -> HTTPS website.')
            print('External/Stash connection must still be verified separately.')
        finally:
            proc.terminate()
            try: proc.communicate(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.communicate()

def rollback():
    check_root()
    meta = get_meta()
    user, gid = identity()
    backup = STATE / 'previous-config.yaml'
    if not backup.is_file() or sha(backup.read_bytes()) != meta['original_sha256']:
        raise Halt('Original backup missing or altered; refusing rollback.')
    restore_from_backup(user, gid, meta)
    undo_firewall(meta)
    meta['state'] = 'rolled_back'
    atomic_secret(STATE / 'metadata.json', json.dumps(meta, indent=2))
    print('ROLLED BACK to original configuration. Backup remains in {}.'.format(STATE))


# Firewalld is optional. Do not touch iptables/nftables or provider-side firewalls.
def firewall_zone():
    if not shutil.which('firewall-cmd'):
        return None
    if run(['systemctl', 'is-active', 'firewalld'], check=False).stdout.strip() != 'active':
        return None
    # Pick the only active zone. Never guess when multiple zones exist.
    active = run(['firewall-cmd', '--get-active-zones'], check=False)
    if active.returncode:
        raise Halt('firewalld is active but active zones cannot be queried.')
    zones = [line.strip().split()[0] for line in active.stdout.splitlines()
             if line and not line[0].isspace()]
    if any(not re.fullmatch(r'[A-Za-z0-9_-]+', z) for z in zones):
        raise Halt('Cannot safely parse active firewalld zones.')
    if len(zones) > 1:
        raise Halt('Several firewalld zones active; cannot safely choose which zone to open for 443: ' + ', '.join(zones))
    if len(zones) == 1:
        return zones[0]
    default = run(['firewall-cmd', '--get-default-zone']).stdout.strip()
    if not default:
        raise Halt('No firewalld default zone found.')
    return default

def ensure_firewall():
    zone = firewall_zone()
    if zone is None:
        print('Firewall: firewalld inactive/absent; no host firewall change.')
        return
    meta = get_meta()
    prefix = ['firewall-cmd', '--zone=' + zone]
    allowed_port = run(prefix + ['--query-port=443/tcp'], check=False).returncode == 0
    allowed_service = run(prefix + ['--query-service=https'], check=False).returncode == 0
    if allowed_port or allowed_service:
        print('Firewall: TCP 443 already permitted in firewalld zone ' + zone)
        return
    # Open only TCP 443. Track exactly what was added for safe reversal.
    run(prefix + ['--add-port=443/tcp'])
    try:
        run(prefix + ['--permanent', '--add-port=443/tcp'])
    except Exception:
        run(prefix + ['--remove-port=443/tcp'], check=False)
        raise
    meta['firewall_port_added_zone'] = zone
    atomic_secret(STATE / 'metadata.json', json.dumps(meta, indent=2))
    print('Firewall: TCP 443 opened (runtime+permanent) in zone ' + zone)

def undo_firewall(meta):
    zone = meta.get('firewall_port_added_zone')
    if not zone:
        return
    if not re.fullmatch(r'[A-Za-z0-9_-]+', zone):
        raise Halt('Invalid saved firewall zone name.')
    if not shutil.which('firewall-cmd'):
        print('WARNING: firewalld tool unavailable; previously added rule may remain.')
        return
    prefix = ['firewall-cmd', '--zone=' + zone]
    run(prefix + ['--remove-port=443/tcp'], check=False)
    run(prefix + ['--permanent', '--remove-port=443/tcp'], check=False)
    print('Firewall: reverted the TCP 443 rule added by this installer.')

def oneclick():
    """No prompts: prepare -> minimally grant bind capability -> apply -> local probe -> firewall.
    Only a confirmed successful local protocol probe finalizes cutover.
    """
    check_root()
    print('=== ONE CLICK: {} / TCP 443 ==='.format(NODE))
    print('Region: US-LA (DMIT Los Angeles); no interactive input.')
    print('Old 18443 XHTTP listener will be replaced; secret backup is retained.')
    if (STATE / 'metadata.json').exists():
        previous = get_meta()
        if previous.get('state') == 'applied' and sha(CONFIG.read_bytes()) == previous.get('candidate_sha256'):
            print('Already applied: {}. No repeated key rotation/restart.'.format(previous['node_name']))
            check()
            return
        raise Halt('Existing rollout state found ({}); refusing to overwrite a possible backup. Inspect it or use rollback.'.format(previous.get('state')))
    prepare(None)  # validates candidate as the service user, no service restart
    try:
        if needs_bind_cap():
            permit443()  # only if non-root needs permission for TCP 443
        apply()  # automatically restores previous config if restart/listener fails
        probe()  # actual local VLESS encryption+REALITY+Vision request
        ensure_firewall()  # after local protocol success
        check()
    except Exception as exc:
        print('ONECLICK ERROR: {}; attempting automatic rollback.'.format(exc), file=sys.stderr)
        try:
            if (STATE / 'metadata.json').exists():
                meta = get_meta()
                if meta.get('state') == 'applied':
                    rollback()
                else:
                    # apply() may have already reverted service and the drop-in
                    undo_firewall(meta)
                    undo_bind443_override(meta)
                    meta['state'] = 'failed_reverted'
                    atomic_secret(STATE / 'metadata.json', json.dumps(meta, indent=2))
        except Exception as rb:
            raise Halt('Automatic rollback failed: {}. Original error: {}'.format(rb, exc))
        raise Halt('Installer reverted service changes. Cause: {}'.format(exc))
    print('\n=== LOCAL VERIFICATION PASSED ===')
    print('Node: {}'.format(NODE))
    print('TCP 443 active. Old XHTTP listener removed from active config (backup kept).')
    print('Stash node YAML: {}'.format(STATE / 'stash-node.yaml'))
    print('Stash standalone YAML: {}'.format(STATE / 'stash-profile.yaml'))
    print('IMPORTANT: Local success does not guarantee Stash/public TCP 443 access.')
    print('If Stash fails, rollback: sudo python3 /root/dmit-us-la/01_vless_pq.py rollback')

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest='command', required=True)
    sub.add_parser('oneclick', help='Unattended deployment, local test, firewall update; rollback on failure')
    sub.add_parser('preflight')
    p = sub.add_parser('prepare')
    # Region is fixed to US-LA, no manual input.
    sub.add_parser('permit443', help='Explicitly grant CAP_NET_BIND_SERVICE via a narrow systemd drop-in if required')
    sub.add_parser('apply')
    sub.add_parser('check')
    sub.add_parser('probe')
    sub.add_parser('rollback')
    args = ap.parse_args()
    try:
        if args.command == 'oneclick': oneclick()
        elif args.command == 'preflight': preflight()
        elif args.command == 'prepare': prepare(args)
        elif args.command == 'permit443': permit443()
        elif args.command == 'apply': apply()
        elif args.command == 'check': check()
        elif args.command == 'probe': probe()
        elif args.command == 'rollback': rollback()
    except (Halt, OSError, subprocess.TimeoutExpired) as e:
        print('ERROR:', e, file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()
