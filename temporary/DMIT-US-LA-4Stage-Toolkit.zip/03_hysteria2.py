#!/usr/bin/env python3
"""03: US-LA-HY2 UDP/443, TLS 1.3 + Salamander; no external daemon installed.
Actions: install | check | rollback | sync-cert
"""
import argparse
import os
from pathlib import Path
import pwd
import secrets
import stat
import subprocess
import sys
import tempfile
import time
import rollout_common as r

NAME='US-LA-HY2'
PORT=443
STAGE='03'
SOURCE=Path('/etc/letsencrypt/live/tt.waylan.org')
DEST=Path('/var/lib/mihomo/us-la-hy2-tls')

def cert_valid(cert,key,user):
    if not cert.is_file() or not key.is_file():return False
    if r.cmd(['test','-r',cert],user=user,check=False).returncode or r.cmd(['test','-r',key],user=user,check=False).returncode:return False
    a=r.cmd(['openssl','x509','-in',cert,'-noout','-checkend','604800'],check=False)
    b=r.cmd(['openssl','x509','-in',cert,'-noout','-checkhost',r.DOMAIN],check=False)
    return a.returncode==0 and b.returncode==0

def certificate_paths(user):
    candidates=[
        (Path('/var/lib/mihomo/tls/fullchain.pem'),Path('/var/lib/mihomo/tls/privkey.pem')),
        (Path('/var/lib/mihomo/tls/cert.pem'),Path('/var/lib/mihomo/tls/key.pem')),
        (Path('/var/lib/mihomo/tls/server.crt'),Path('/var/lib/mihomo/tls/server.key')),
        (DEST/'fullchain.pem',DEST/'privkey.pem'),
    ]
    for cert,key in candidates:
        if cert_valid(cert,key,user):return cert,key,False
    if not (SOURCE/'fullchain.pem').is_file() or not (SOURCE/'privkey.pem').is_file():
        raise r.Stop('No service-readable certificate pair, and existing Let\'s Encrypt source not found.')
    # Verify source certificate before copying it into a service-readable private directory.
    check=r.cmd(['openssl','x509','-in',SOURCE/'fullchain.pem','-noout','-checkend','604800'],check=False)
    host=r.cmd(['openssl','x509','-in',SOURCE/'fullchain.pem','-noout','-checkhost',r.DOMAIN],check=False)
    if check.returncode or host.returncode:
        raise r.Stop('Let\'s Encrypt certificate expires within 7 days or does not match '+r.DOMAIN)
    return DEST/'fullchain.pem',DEST/'privkey.pem',True

def copy_certs(user,gid):
    if DEST.is_symlink():raise r.Stop('TLS destination is a symlink.')
    DEST.mkdir(parents=True,exist_ok=True,mode=0o750)
    os.chown(DEST,0,gid);os.chmod(DEST,0o750)
    r.secret_file(DEST/'fullchain.pem',(SOURCE/'fullchain.pem').read_bytes(),mode=0o640,gid=gid)
    r.secret_file(DEST/'privkey.pem',(SOURCE/'privkey.pem').read_bytes(),mode=0o640,gid=gid)
    if not cert_valid(DEST/'fullchain.pem',DEST/'privkey.pem',user):
        raise r.Stop('Copied TLS certificate is not accessible or fails checks.')

def install():
    user,gid=r.environment()
    cert,key,mustcopy=certificate_paths(user)
    password=secrets.token_urlsafe(36)
    obfs=secrets.token_urlsafe(36)
    listener=f'''  - name: {r.q(NAME)}
    type: hysteria2
    listen: 0.0.0.0
    port: {PORT}
    users:
      la: {r.q(password)}
    ignore-client-bandwidth: true
    bbr-profile: standard
    obfs: salamander
    obfs-password: {r.q(obfs)}
    alpn:
      - h3
    certificate: {r.q(str(cert))}
    private-key: {r.q(str(key))}
'''
    node=f'''  - name: {r.q(NAME)}
    type: hysteria2
    server: {r.q(r.DOMAIN)}
    port: {PORT}
    auth: {r.q(password)}
    fast-open: true
    obfs: salamander
    obfs-password: {r.q(obfs)}
    sni: {r.q(r.DOMAIN)}
    skip-cert-verify: false
    alpn:
      - h3
'''
    def preapply(folder,u,g):
        if mustcopy:
            copy_certs(u,g)
            print('[CERT] Created service-readable TLS copy. See README for renewal sync.',flush=True)
        if not cert_valid(cert,key,u):
            raise r.Stop('TLS certificate not accessible to non-root Mihomo or hostname/expiry invalid.')
    r.deploy(STAGE,NAME,PORT,'udp',listener,node,
        [('US-LA-VLESS-PQ','vless',443),('US-LA-MIERU','mieru',8443)],udp=True,preapply=preapply)

def check():
    folder=r.STATE/STAGE; meta=r.load_meta(folder)
    if meta['state']!='applied':raise r.Stop('HY2 not successfully installed.')
    r.environment()
    if not r.listens(PORT,udp=True):raise r.Stop('HY2 UDP 443 not listening.')
    r.socks_probe((folder/'stash-node.yaml').read_text().removeprefix('proxies:\n'),port=PORT,udp=True)
    print('[PASS] '+NAME+' UDP/443 and end-to-end proxy test; public UDP reachability still unproven.')

def sync_cert():
    """Manual post-renewal copy for certificates staged by this installer."""
    user,gid=r.environment()
    if not (r.STATE/STAGE/'meta.json').is_file():raise r.Stop('HY2 stage not installed.')
    if not DEST.is_dir():
        raise r.Stop('Installer did not use private TLS copy; inspect existing certificate renewal hook.')
    cert,key,mustcopy=certificate_paths(user)
    # Source might be renewed but destination old; skip existing pair selection.
    backup1=(DEST/'fullchain.pem').read_bytes();backup2=(DEST/'privkey.pem').read_bytes()
    try:
        copy_certs(user,gid)
        r.cmd(['systemctl','restart',r.SERVICE],timeout=45)
        if not r.listens(PORT,udp=True) or not r.listens(443):raise r.Stop('Service not listening after certificate refresh.')
    except Exception:
        r.secret_file(DEST/'fullchain.pem',backup1,mode=0o640,gid=gid)
        r.secret_file(DEST/'privkey.pem',backup2,mode=0o640,gid=gid)
        r.cmd(['systemctl','restart',r.SERVICE],check=False)
        raise
    print('[PASS] TLS copies refreshed; Mihomo restarted and listeners checked.')

def main():
    p=argparse.ArgumentParser();p.add_argument('action',nargs='?',default='install',choices=['install','check','rollback','sync-cert'])
    act=p.parse_args().action
    if act=='install':install()
    elif act=='check':check()
    elif act=='rollback':r.restore_stage(STAGE)
    else:sync_cert()

if __name__=='__main__':
    try:main()
    except (r.Stop,OSError,ValueError) as e:
        print('[STOP] '+str(e),file=sys.stderr);sys.exit(1)
