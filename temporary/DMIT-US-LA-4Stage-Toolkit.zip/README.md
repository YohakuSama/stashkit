# DMIT US-LA | Mihomo v1.19.33 | 全套分阶段部署包

> **目标**：原有 Mihomo 单服务，Rocky Linux 10.2，非 root systemd 用户，Stash iOS 3.6.5。**不安装第二套代理服务、不升级内核**。只使用 Python 3 标准库、现有 Mihomo、curl、openssl、ss、systemctl。
>
> 本包内不包含任何真实密码、UUID、密钥。它们**在你的 VPS 本地随机生成**。不需要交互输入。

## 0. 节点与端口

| 顺序 | 文件 | 节点名 | 技术 | 端口 |
|---|---|---|---|---|
| 00 | `00_cleanup.py` | — | 安全清理历史 TrustTunnel 测试残留 | — |
| 01 | `01_vless_pq.py` | `US-LA-VLESS-PQ` | VLESS Encryption ML-KEM768/X25519 + REALITY + RAW TCP + Vision | **TCP 443** |
| 02 | `02_mieru.py` | `US-LA-MIERU` | Mieru TCP + 多路复用 MIDDLE + STANDARD 握手 | **TCP 8443** |
| 03 | `03_hysteria2.py` | `US-LA-HY2` | Hysteria2 QUIC + TLS + Salamander + 标准 BBR | **UDP 443** |

**TCP 与 UDP 443 不冲突。** 8443 是常见 HTTPS 替代端口，并非唯一官方标准端口。`rollout_common.py` 是 02/03 阶段的共享依赖，不要删除。

## 1. 下载与上传

在 ChatGPT 下载 ZIP，保存到电脑或手机。**`sandbox:` 不能直接在 VPS 上通过 wget/curl 使用**。

电脑上传（自行替换 VPS IP；SSH 非 22 端口时使用 `scp -P 端口`）：

```bash
scp DMIT-US-LA-Complete-4Stages.zip root@YOUR_VPS_IP:/root/
```

使用手机时，通过 SSH 客户端的 SFTP 上传到 `/root/`。随后 SSH 登录 VPS，执行：

```bash
mkdir -p /root/dmit-us-la
unzip /root/DMIT-US-LA-Complete-4Stages.zip -d /root/dmit-us-la
cd /root/dmit-us-la
ls -l 0*.py rollout_common.py
```

没有 `unzip` 工具时：可以在电脑/手机解压后，通过 SFTP 把整个 `dmit-us-la` 文件夹上传到 `/root/`，无需在 VPS 安装 `unzip`。

## 2. 按顺序执行（推荐 **一次一个阶段**）

通过 **DMIT 控制台或直接 SSH** 操作，不要仅依赖将被替换的旧 XHTTP 代理接入服务器。

### 00：安全清理历史测试残留

```bash
sudo python3 /root/dmit-us-la/00_cleanup.py clean
```

运行前可用 `audit` 只查看。清理脚本会隔离已确认的旧测试文件，且**不会删除旧工作配置备份、真实证书或有效节点**。它仅移除识别准确的 TrustTunnel 18444 监听。6 个阶段出现 STOP 就不要继续。

清理回退：

```bash
sudo python3 /root/dmit-us-la/00_cleanup.py restore
```

### 01：VLESS 后量子主节点

```bash
sudo python3 /root/dmit-us-la/01_vless_pq.py oneclick
```

- 先检查：只有一个已工作 VLESS listener、`/etc/mihomo/config.yaml`、Mihomo `1.19.33`、REALITY SNI/Dest、空闲 TCP 443 等。
- 自动在 VPS 本地生成密钥；先以服务用户校验候选配置，再重启并本机通过新 VLESS 连接 HTTPS。**失败会尝试恢复旧配置。**
- 旧 TCP 18443 XHTTP listener 将从活动配置中被替换；旧配置保存在 `/etc/mihomo/us-la-rollout/01/previous-config.yaml`，**并未永久删除**。
- 非 root 绑定 443 如确有必要，只添加最小的 `CAP_NET_BIND_SERVICE` systemd drop-in；不会修改 sysctl/内核。
- Stash 配置文件：`/etc/mihomo/us-la-rollout/01/stash-node.yaml` 和 `stash-profile.yaml`。

失败或 Stash 实测失败后回退（前提是还未安装 02/03）：

```bash
sudo python3 /root/dmit-us-la/01_vless_pq.py rollback
```

### 02：Mieru 副节点

**前提**：01 本机检查和 Stash 公网实测均成功。

```bash
sudo python3 /root/dmit-us-la/02_mieru.py install
```

自动生成独立高强度账号密码，追加 Mieru TCP 8443 listener。优先使用 `MULTIPLEXING_MIDDLE`，`HANDSHAKE_STANDARD`。Mieru 的 `traffic-pattern` 需要官方导出的 protobuf Base64；本包不塞未经验证的自定义流量模板，保留协议内建的流量行为。

每个新增阶段均按八步检查：**预检 → 备份 → 校验 → 应用 → 真实本地代理连接 → 防火墙 → 最终检查 → 客户端配置**。自动检查失败会尝试恢复该阶段开始前的配置。

检测与回退：

```bash
sudo python3 /root/dmit-us-la/02_mieru.py check
sudo python3 /root/dmit-us-la/02_mieru.py rollback
```

### 03：Hysteria2 UDP 实验节点

**前提**：01、02 本机检查和 Stash 公网实测均成功。

```bash
sudo python3 /root/dmit-us-la/03_hysteria2.py install
```

使用 `tt.waylan.org` 的有效 Let's Encrypt 证书，严格校验证书；启用 Salamander（独立随机密码）与标准 BBR；不虚构带宽上限，不配置无意义的端口跳跃。优先复用服务用户可读的 `/var/lib/mihomo/tls` 证书副本；否则从当前 LE 证书复制到专用的 `/var/lib/mihomo/us-la-hy2-tls` 并设置严格权限。

**证书续期注意**：如果安装时新建了专用证书副本，后续 Certbot 续期后必须同步副本，可以执行：

```bash
sudo python3 /root/dmit-us-la/03_hysteria2.py sync-cert
```

本包**不擅自添加 Certbot 自动钩子**。你可以将此命令加入原有续期部署钩子，但应先确认现有 Certbot 续期方式。

检测与回退：

```bash
sudo python3 /root/dmit-us-la/03_hysteria2.py check
sudo python3 /root/dmit-us-la/03_hysteria2.py rollback
```

## 3. Stash 配置位置

安装 01 后：`/etc/mihomo/us-la-rollout/01/stash-profile.yaml`。

安装 02、03 后：`/etc/mihomo/us-la-rollout/stash-all.yaml`（动态合并已安装节点）。

这些文件**包含私密认证参数**，仅通过 SFTP/SCP 私下下载到手机，不要粘贴到公共聊天或在线 YAML 编辑网站。独立 profile 自带 `MATCH` 策略，用于测试；如果你希望保留原有 Stash 分流规则，应导入相应 `stash-node.yaml` 并合并 `proxies:` 列表，切勿盲目覆盖现有分流配置。

## 4. 明确限制与安全策略

- **这是四个阶段，不是一次性盲目部署全部**：服务器端阶段之间有自动门禁；但**无法自动从 VPS 判断 iPhone Stash 的公网连接**，因此每阶段成功后，须先在 Stash 确认再运行下一个。
- 配置本身先经 `mihomo -t` 校验，且进行真实的临时本地 Mihomo 客户端至 HTTPS 网站测试。**本机成功 != DMIT 公网端口已通**，尤其 UDP 443。
- 系统 firewalld 如启用，脚本只在明确唯一活动区域时为该阶段单独放行对应端口；无法识别则停止。**DMIT 供应商后台防火墙不在脚本控制范围内**。
- 01 主节点在 `443/tcp`，02 追加 `8443/tcp`，03 追加 `443/udp`，均使用现有一个 Mihomo systemd 服务。失败后不会主动删除旧备份或 TLS 证书。
- 回退次序必须与安装相反：**03 → 02 → 01**。不能有新节点后直接回退 01，因为那会覆盖后来新增的节点。
- `00_cleanup.py` 只识别历史 TrustTunnel；如当前配置已变化、存在未知监听器或旧阶段工具已运行，安全门禁可能拒绝操作，停止并查看结果，不要手动强行删除。
- 软件版本严格限制到已知 `Mihomo v1.19.33`。真实 VPS 的连接、证书续期、上游网络出口在此环境无法提前验证。

## 5. 配置依据（官方）

- Mihomo VLESS: https://wiki.metacubex.one/en/config/inbound/listeners/vless/
- Mihomo Mieru: https://wiki.metacubex.one/en/config/inbound/listeners/mieru/
- Mihomo Hysteria2: https://wiki.metacubex.one/en/config/inbound/listeners/hysteria2/
- Stash protocols: https://stash.wiki/proxy-protocols/proxy-types
- Mieru traffic pattern format: https://github.com/enfein/mieru/blob/main/docs/traffic-pattern.md
