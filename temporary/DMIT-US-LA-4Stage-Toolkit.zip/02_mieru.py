#!/usr/bin/env python3
"""02: US-LA-MIERU TCP/8443; run: sudo python3 02_mieru.py install|check|rollback."""
import argparse
import secrets
import sys
from pathlib import Path
import rollout_common as r

NAME='US-LA-MIERU'
PORT=8443
STAGE='02'

def install():
    username='la'+secrets.token_hex(4)
    password=secrets.token_urlsafe(36)
    listener=f'''  - name: {r.q(NAME)}
    type: mieru
    listen: 0.0.0.0
    port: {PORT}
    transport: TCP
    users:
      {username}: {r.q(password)}
'''
    node=f'''  - name: {r.q(NAME)}
    type: mieru
    server: {r.q(r.DOMAIN)}
    port: {PORT}
    transport: tcp
    username: {r.q(username)}
    password: {r.q(password)}
    multiplexing: MULTIPLEXING_MIDDLE
    handshake-mode: HANDSHAKE_STANDARD
'''
    # Official Mieru traffic-pattern format is a protobuf payload, NOT base64(JSON).
    # Keep well-supported implicit traffic patterns rather than inventing bytes.
    r.deploy(STAGE,NAME,PORT,'tcp',listener,node,[('US-LA-VLESS-PQ','vless',443)])

def check():
    folder=r.STATE/STAGE
    meta=r.load_meta(folder)
    if meta['state']!='applied':raise r.Stop('Mieru not successfully installed.')
    u,g=r.environment()
    if not r.listens(PORT):raise r.Stop('Mieru TCP 8443 not listening.')
    r.socks_probe((folder/'stash-node.yaml').read_text().removeprefix('proxies:\n'),port=PORT)
    print('[PASS] '+NAME+' server and local end-to-end proxy test')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('action',nargs='?',default='install',choices=['install','check','rollback'])
    a=ap.parse_args()
    if a.action=='install':install()
    elif a.action=='check':check()
    else:r.restore_stage(STAGE)

if __name__=='__main__':
    try:main()
    except (r.Stop,OSError,ValueError) as e:
        print('[STOP] '+str(e),file=sys.stderr);sys.exit(1)
