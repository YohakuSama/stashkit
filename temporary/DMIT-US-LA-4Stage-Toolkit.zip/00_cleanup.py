#!/usr/bin/env python3
"""DMIT US-LA Mihomo safe legacy cleanup, Python 3 standard library only.

sudo python3 /root/dmit_cleanup.py clean
sudo python3 /root/dmit_cleanup.py audit
sudo python3 /root/dmit_cleanup.py restore

No package install. Does not delete live config, keys, certs, or backups.
Old test artifacts are quarantined, not permanently deleted.
"""
import argparse
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time

BIN = Path('/usr/local/bin/mihomo')
CONFIG = Path('/etc/mihomo/config.yaml')
HOME = Path('/var/lib/mihomo')
BASE = Path('/root/mihomo-cleanup-quarantine')
LOCK = Path('/run/dmit-mihomo-cleanup.lock')
ROLLOUT = Path('/etc/mihomo/vision-rollout/metadata.json')
SERVICE = 'mihomo'
# Exact known previous temporary files only. No glob, recursive deletion, or wildcard.
TEST_FILES = (
    Path('/root/trusttunnel-password.txt'),
    Path('/root/stash-trusttunnel-h2-test.yaml'),
    Path('/root/stash-trusttunnel-h3-test.yaml'),
    Path('/etc/mihomo/config.trusttunnel.candidate.yaml'),
    Path('/root/config.trusttunnel.candidate.yaml'),
)
# These are retired installers; protected if Vision rollout state exists.
RETIRED_INSTALLERS = (
    Path('/root/dmit_vless_vision.py'),
    Path('/root/dmit_vision_443.py'),
    Path('/root/dmit_us_la_vision_oneclick.py'),
    Path('/root/DMIT-VLESS-PQ-Vision-rollout.zip'),
    Path('/root/DMIT-Standard-Ports-Vision.zip'),
    Path('/root/DMIT-US-LA-Vision-OneClick.zip'),
)

class Halt(Exception):
    pass


def report(stage, message, status='INFO'):
    print(f'[{stage}/6] [{status}] {message}', flush=True)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def call(args, *, user=None, timeout=60, check=True):
    kw = {}
    env = os.environ.copy()
    if user:
        account = pwd.getpwnam(user)
        def demote():
            os.initgroups(user, account.pw_gid)
            os.setgid(account.pw_gid)
            os.setuid(account.pw_uid)
        kw['preexec_fn'] = demote
        env['HOME'] = str(HOME)
    p = subprocess.run(list(map(str,args)), capture_output=True, text=True, timeout=timeout, env=env, **kw)
    if check and p.returncode != 0:
        raise Halt(f"Failed command: {args[0]} (exit {p.returncode})\n{(p.stderr or p.stdout)[-1200:]}")
    return p


def baseline():
    if os.geteuid() != 0:
        raise Halt('Run this script as root using sudo.')
    if not CONFIG.is_file() or CONFIG.is_symlink() or not BIN.is_file():
        raise Halt('Expected regular Mihomo config and binary; no safe automatic action.')
    if not HOME.is_dir():
        raise Halt('Missing Mihomo home directory /var/lib/mihomo.')
    username = call(['systemctl','show',SERVICE,'-p','User','--value']).stdout.strip()
    if not username or username == 'root':
        raise Halt('Expected a non-root systemd Mihomo service; check manually.')
    pwd.getpwnam(username)
    active = call(['systemctl','is-active',SERVICE], check=False).stdout.strip()
    if active != 'active':
        raise Halt('Mihomo is not active. Do not clean during an existing service problem.')
    version = call([BIN,'-v'],timeout=15).stdout.strip().splitlines()[0]
    if '1.19.33' not in version:
        raise Halt(f'Unexpected Mihomo version: {version}; script tailored for v1.19.33.')
    raw = CONFIG.read_bytes()
    validate(CONFIG, username)
    return username, raw, version


def validate(path, username):
    r = call([BIN,'-t','-d',HOME,'-f',path], user=username, timeout=90, check=False)
    if r.returncode:
        raise Halt('Mihomo config validation failed: ' + (r.stderr or r.stdout)[-1400:])


def listener_sections(raw):
    """Strictly parse only simple top-level YAML listeners block. Refuse unknown formatting."""
    try:
        lines = raw.decode('utf-8').splitlines(keepends=True)
    except UnicodeDecodeError as e:
        raise Halt('Config must be UTF-8.') from e
    keys = [i for i,line in enumerate(lines) if re.match(r'^listeners:\s*(?:#.*)?$',line.rstrip('\r\n'))]
    if len(keys) != 1:
        raise Halt('Expected one explicit top-level multiline listeners: block; will not rewrite unknown YAML.')
    start = keys[0]
    end = len(lines)
    for i in range(start + 1,len(lines)):
        line = lines[i]
        if re.match(r'^[A-Za-z_][\w-]*\s*:',line) or re.match(r'^\S',line) and not line.startswith('#'):
            end = i
            break
    section = lines[start+1:end]
    items = []
    for i,line in enumerate(section):
        if re.match(r'^  -\s+\S',line):
            items.append(i)
        elif re.match(r'^ {0,1}-\s+\S',line):
            raise Halt('Unrecognized listeners list indentation; refusing change.')
    if not items:
        raise Halt('No conventional top-level listeners list; refusing change.')
    blocks = [section[items[k] : items[k+1] if k+1<len(items) else len(section)] for k in range(len(items))]
    def info(block):
        text = ''.join(block)
        typ = re.findall(r'(?m)^    type:\s*[\'\"]?([\w-]+)',text)
        ports = re.findall(r'(?m)^    port:\s*[\'\"]?(\d+)',text)
        if len(typ) != 1 or len(ports) != 1:
            raise Halt('Listener missing unique type / port at 4-space indentation.')
        return typ[0].lower(),int(ports[0])
    parsed = [info(b) for b in blocks]
    return lines, start, end, section, blocks, parsed


def candidate_without_tt(raw):
    lines, start, end, section, blocks, parsed = listener_sections(raw)
    tt = [i for i,x in enumerate(parsed) if x[0]=='trusttunnel']
    if not tt:
        return None, parsed
    if len(tt) != 1 or parsed[tt[0]] != ('trusttunnel',18444):
        raise Halt('Unknown TrustTunnel listener configuration; refusing automatic removal.')
    if ('vless',18443) not in parsed:
        raise Halt('Cannot find known working VLESS listener on TCP 18443; refusing cutover.')
    selected = []
    for i, block in enumerate(blocks):
        if i != tt[0]:
            selected.extend(block)
    prefix = lines[:start+1]
    suffix = lines[end:]
    result = ''.join(prefix + selected + suffix).encode('utf-8')
    if result == raw:
        raise Halt('TrustTunnel removal produced no change.')
    return result, parsed


def is_listening(port,udp=False):
    flag = '-H -lnu' if udp else '-H -lnt'
    return bool(call(['ss', *flag.split(), f'( sport = :{port} )'], check=False, timeout=8).stdout.strip())


def ref_scan(path, service_text, live_text):
    s = str(path)
    return s in live_text or s in service_text


def manifest_write(run_dir, manifest):
    dest = run_dir / 'manifest.json'
    payload = json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8')
    fd, tmp = tempfile.mkstemp(prefix='.manifest-',dir=run_dir)
    try:
        os.fchmod(fd,0o600)
        with os.fdopen(fd,'wb') as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp,dest)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)


def atomic_config(content, original_stat):
    fd, tmp = tempfile.mkstemp(prefix='.config-cleanup-',dir=CONFIG.parent)
    try:
        os.fchmod(fd,stat.S_IMODE(original_stat.st_mode))
        os.fchown(fd,original_stat.st_uid,original_stat.st_gid)
        with os.fdopen(fd,'wb') as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp,CONFIG)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)


def save_secret(path, content):
    fd = os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as f:
        f.write(content)
        f.flush()
        os.fsync(f.fileno())


def safe_restart():
    call(['systemctl','restart',SERVICE],timeout=50)
    time.sleep(0.8)
    if call(['systemctl','is-active',SERVICE],check=False).stdout.strip()!='active':
        raise Halt('Service failed to become active.')


def create_run():
    if BASE.is_symlink():
        raise Halt('Recovery directory is a symlink; refusing.')
    BASE.mkdir(mode=0o700,parents=True,exist_ok=True)
    os.chmod(BASE,0o700)
    run_dir = BASE / ('run-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + f'-{os.getpid()}')
    run_dir.mkdir(mode=0o700)
    (run_dir/'files').mkdir(mode=0o700)
    return run_dir


def rollback_partial(run_dir, manifest, original, orig_stat):
    """Best-effort recovery if a later cleanup step fails; never overwrite newer config."""
    for item in reversed(manifest.get('files', [])):
        src = Path(item['quarantine'])
        dst = Path(item['original'])
        if src.is_file() and not src.is_symlink() and not dst.exists() and not dst.is_symlink():
            if digest(src.read_bytes()) == item['sha256']:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(src), str(dst))
                print(f'[ROLLBACK] Restored quarantined file: {dst}', flush=True)
    if manifest.get('config_changed') and manifest['after_sha256'] != manifest['original_sha256']:
        if CONFIG.is_file() and digest(CONFIG.read_bytes()) == manifest['after_sha256']:
            atomic_config(original, orig_stat)
            safe_restart()
            print('[ROLLBACK] Restored original Mihomo config and restarted service.', flush=True)
        else:
            print('[ROLLBACK] Config changed externally; original snapshot remains in recovery directory.', flush=True)
    manifest['state'] = 'rolled-back'
    manifest_write(run_dir, manifest)


def audit_or_clean(do_clean):
    report(1,'Baseline: checking Mihomo process, version and configuration...')
    user, original, version = baseline()
    original_sha = digest(original)
    report(1, f'{version}; systemd user={user}; live config SHA256={original_sha[:16]}', 'PASS')

    report(2,'Inventory: inspecting live listeners and historic test artifacts...')
    candidate, listeners = candidate_without_tt(original)
    report(2,'Configured listeners: '+', '.join(f'{t}:{p}' for t,p in listeners),'INFO')
    report(2,'Ports: '+', '.join(f'{p}/{proto}={"ON" if is_listening(p, proto=="udp") else "OFF"}' for p,proto in [(18443,'tcp'),(18444,'tcp'),(18444,'udp'),(443,'tcp'),(443,'udp')]))
    # No quarantining files actively referenced by the unit or config.
    service_text = call(['systemctl','cat',SERVICE],check=False).stdout
    live_text = original.decode('utf-8',errors='replace')
    protected_rollout = ROLLOUT.exists() or ('vless',18443) not in listeners
    if protected_rollout:
        report(2,'Rollout metadata exists or working VLESS:18443 not found; protecting previous installers/rollback files.','SKIP')
    candidates = list(TEST_FILES) + ([] if protected_rollout else list(RETIRED_INSTALLERS))
    movable, skipped = [], []
    for path in candidates:
        if not path.exists() and not path.is_symlink():
            continue
        if path.is_symlink() or not path.is_file():
            skipped.append((path,'not a regular file'))
        elif ref_scan(path,service_text,live_text):
            skipped.append((path,'referenced by live config or systemd unit'))
        else:
            movable.append(path)
    for path,why in skipped:
        report(2,f'PROTECTED: {path} ({why})','SKIP')
    report(2,f'Cleanup candidates: {len(movable)} exact historic files; active TrustTunnel listener: {"YES" if candidate else "NO"}', 'PASS')
    report(2,'Always protected: active config backups; Let\'s Encrypt certs; cert copies for HY2; mihomo binary/unit; all unknown paths.','INFO')
    if candidate is None and (is_listening(18444) or is_listening(18444,True)):
        report(2,'Port 18444 is in use but not by recognized TrustTunnel listener; will NOT kill unknown process.','SKIP')
    if not do_clean:
        report(6,'AUDIT COMPLETE; no files or services changed.','PASS')
        return
    if not candidate and not movable:
        report(6,'ALREADY CLEAN: no confirmed obsolete artifacts; nothing changed.','PASS')
        return

    report(3,'Preparing root-only recovery snapshot and validating proposed changes...')
    run_dir = create_run()
    orig_stat = CONFIG.stat()
    manifest = {
        'run_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'state':'preparing',
        'original_sha256': original_sha,
        'after_sha256':original_sha,
        'config_changed': False,
        'files':[],
        'original_mode':stat.S_IMODE(orig_stat.st_mode),
        'original_uid':orig_stat.st_uid,
        'original_gid':orig_stat.st_gid,
    }
    save_secret(run_dir/'original-config.yaml',original)
    manifest_write(run_dir,manifest)
    if candidate is not None:
        # Nonroot config verifier needs permission to read candidate, but not our backups.
        fd,tmp=tempfile.mkstemp(prefix='.clean-verify-',dir=CONFIG.parent)
        try:
            os.fchown(fd,0,pwd.getpwnam(user).pw_gid)
            os.fchmod(fd,0o640)
            with os.fdopen(fd,'wb') as f: f.write(candidate)
            validate(Path(tmp),user)
        finally:
            if os.path.exists(tmp):os.unlink(tmp)
        report(3,'Candidate VLESS-only config passed non-root Mihomo validation.','PASS')
    else:
        report(3,'No live listener modification required.','PASS')
    report(3,f'Recovery snapshot: {run_dir} (root-only).','PASS')

    try:
        report(4,'Applying confirmed changes with checks and automatic rollback on failure...')
        if candidate is not None:
            if digest(CONFIG.read_bytes()) != original_sha:
                raise Halt('Live config changed during cleanup, refusing to overwrite it.')
            atomic_config(candidate,orig_stat)
            manifest['config_changed']=True
            manifest['after_sha256']=digest(candidate)
            manifest['state']='config-swapped'
            manifest_write(run_dir,manifest)
            try:
                safe_restart()
                if not is_listening(18443):
                    raise Halt('Expected the original working VLESS TCP 18443 to be listening.')
                if is_listening(18444) or is_listening(18444,True):
                    raise Halt('Port 18444 still has a listener after TrustTunnel removal; will roll back.')
                validate(CONFIG,user)
            except Exception as e:
                report(4,'Config health check failed: attempting immediate restore.','FAIL')
                atomic_config(original,orig_stat)
                safe_restart()
                manifest['state']='rolled-back'
                manifest['after_sha256']=original_sha
                manifest_write(run_dir,manifest)
                raise Halt(f'Old configuration restored after failure: {e}') from e
            report(4,'Removed only TrustTunnel:18444 from active config; VLESS 18443 remains listening.','PASS')
        else:
            report(4,'No config change and no service restart.','SKIP')
        report(5,'Quarantining unused historic files (not deleting them)...')
        for src in movable:
            if not src.is_file() or src.is_symlink() or ref_scan(src,call(['systemctl','cat',SERVICE],check=False).stdout,CONFIG.read_text(errors='replace')):
                report(5,f'File changed or became referenced; skipping: {src}','SKIP')
                continue
            dst = run_dir/'files'/src.as_posix().lstrip('/')
            dst.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
            if dst.exists() or dst.is_symlink():
                raise Halt(f'Quarantine destination exists: {dst}')
            # Same-FS rename is atomic; use shutil.move for distinct mounts (no symlinks allowed).
            shutil.move(str(src),str(dst))
            manifest['files'].append({'original':str(src),'quarantine':str(dst),'sha256':digest(dst.read_bytes())})
            manifest['state']='files-quarantined'
            manifest_write(run_dir,manifest)
            report(5,f'QUARANTINED {src}','PASS')
        report(5,f'Quarantined {len(manifest["files"])} obsolete file(s); no permanent deletion.','PASS')
        report(6,'Final verification: service, config, active TCP 18443, recovery manifest...')
        validate(CONFIG,user)
        expected=manifest['after_sha256']
        if digest(CONFIG.read_bytes()) != expected:
            raise Halt('Config was modified during cleanup. Inspect live file; no auto-overwrite.')
        if call(['systemctl','is-active',SERVICE],check=False).stdout.strip()!='active':
            raise Halt('Mihomo inactive after cleanup.')
        if ('vless',18443) in listeners and not is_listening(18443):
            raise Halt('VLESS TCP 18443 no longer listening.')
        manifest['state']='complete'
        manifest_write(run_dir,manifest)
        report(6,f'ALL CHECKS PASS; recovery directory: {run_dir}','PASS')
        report(6,'TLS certificates, SSL copies, old working config and Vision rollout recovery left untouched.','PASS')
        report(6,'If needed: sudo python3 /root/dmit_cleanup.py restore','INFO')
    except Exception:
        # Never delete recovery material. Restore only files/config that are still byte-for-byte
        # the artifacts created during this run; external edits are not overwritten.
        try:
            rollback_partial(run_dir, manifest, original, orig_stat)
        except Exception as rollback_error:
            print(f'[ROLLBACK WARNING] Automatic recovery incomplete: {rollback_error}', file=sys.stderr, flush=True)
            manifest_write(run_dir,manifest)
        raise


def restore_latest():
    if not BASE.is_dir():
        raise Halt('No cleanup quarantine directory found.')
    dirs = sorted([p for p in BASE.glob('run-*') if (p/'manifest.json').is_file()])
    if not dirs:
        raise Halt('No cleanup recovery manifest found.')
    run_dir=dirs[-1]
    manifest=json.loads((run_dir/'manifest.json').read_text())
    if manifest.get('state') == 'restored':
        report(6,'Latest cleanup is already restored.','PASS')
        return
    report(1,f'Recovery bundle: {run_dir}')
    if os.geteuid()!=0:raise Halt('Run with sudo.')
    # Check optional active config BEFORE any file moves.
    if manifest.get('config_changed') and manifest.get('after_sha256') != manifest.get('original_sha256'):
        if not CONFIG.is_file() or digest(CONFIG.read_bytes()) != manifest['after_sha256']:
            raise Halt('Live config changed since cleanup; refusing overwrite. Recover files manually if needed.')
    report(2,'Restoring quarantined files without overwriting existing paths...')
    for item in reversed(manifest.get('files',[])):
        src=Path(item['quarantine']); dst=Path(item['original'])
        if not src.exists():
            if dst.exists() and digest(dst.read_bytes())==item['sha256']:
                report(2,f'Already restored: {dst}','SKIP');continue
            raise Halt(f'Missing quarantined file: {src}')
        if dst.exists() or dst.is_symlink():
            raise Halt(f'Refusing to overwrite existing file: {dst}')
        if not src.is_file() or src.is_symlink() or digest(src.read_bytes())!=item['sha256']:
            raise Halt(f'Quarantine file changed: {src}')
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.move(str(src),str(dst))
        report(2,f'Restored {dst}','PASS')
    report(3,'Restoring previous Mihomo listeners only if cleanup changed them...')
    if manifest.get('config_changed') and manifest.get('after_sha256')!=manifest.get('original_sha256'):
        original=(run_dir/'original-config.yaml').read_bytes()
        if digest(original)!=manifest['original_sha256']:
            raise Halt('Recovery config digest mismatch; stop.')
        st=CONFIG.stat()
        atomic_config(original,st)
        safe_restart()
        report(3,'Original live config restored and service restarted.','PASS')
    else:
        report(3,'Live config was not changed by cleanup.','SKIP')
    report(4,'Verifying restored Mihomo config...')
    user,raw,version=baseline()
    manifest['state']='restored'
    manifest_write(run_dir,manifest)
    report(6,'RECOVERY PASS. Original artifacts restored.','PASS')


def main():
    a=argparse.ArgumentParser(description='Safe Mihomo/TrustTunnel historical cleanup with stage gates and recovery')
    a.add_argument('action',nargs='?',default='clean',choices=['audit','clean','restore'])
    args=a.parse_args()
    if os.geteuid()!=0:
        raise Halt('Must run with sudo/root.')
    lock_fd=os.open(LOCK,os.O_WRONLY|os.O_CREAT,0o600)
    try:
        fcntl.flock(lock_fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        raise Halt('Another cleanup operation is already running.')
    try:
        if args.action=='restore':restore_latest()
        else:audit_or_clean(args.action=='clean')
    finally:
        os.close(lock_fd)

if __name__=='__main__':
    try:
        main()
    except (Halt, OSError, subprocess.TimeoutExpired) as e:
        print(f'\n[STOP] {e}\nNo forced deletion. Inspect printed stages before retrying.',file=sys.stderr,flush=True)
        sys.exit(1)
