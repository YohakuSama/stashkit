#!/usr/bin/env python3
"""Shared, stdlib-only, gated Mihomo listener deployment helpers.
Private credentials are written only to root-owned files on the VPS.
"""
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import secrets
import shutil
import socket
import stat
import subprocess
import tempfile
import time

CONFIG=Path('/etc/mihomo/config.yaml')
BIN=Path('/usr/local/bin/mihomo')
MIHOME=Path('/var/lib/mihomo')
STATE=Path('/etc/mihomo/us-la-rollout')
SERVICE='mihomo'
DOMAIN='tt.waylan.org'
LOCK=Path('/run/dmit-us-la-rollout.lock')

class Stop(Exception): pass

def tell(num,msg,kind='INFO'):
    print(f'[{num}/8] [{kind}] {msg}',flush=True)

def cmd(args, *, user=None, check=True, timeout=70):
    opts={}
    env=os.environ.copy()
    if user:
        acct=pwd.getpwnam(user)
        def drop():
            os.initgroups(user,acct.pw_gid)
            os.setgid(acct.pw_gid)
            os.setuid(acct.pw_uid)
        opts['preexec_fn']=drop
        env['HOME']=str(MIHOME)
    try:
        res=subprocess.run(list(map(str,args)),text=True,capture_output=True,timeout=timeout,env=env,**opts)
    except subprocess.TimeoutExpired as exc:
        raise Stop('Timed out: '+str(args[0])) from exc
    if check and res.returncode:
        raise Stop(f'Command {args[0]} exited {res.returncode}: {(res.stderr or res.stdout)[-800:]}')
    return res

def digest(b): return hashlib.sha256(b).hexdigest()
def q(s): return json.dumps(s,ensure_ascii=True)

def assert_root():
    if os.geteuid()!=0: raise Stop('Use sudo/root; no files changed.')

def acquire():
    assert_root()
    fd=os.open(LOCK,os.O_CREAT|os.O_RDWR,0o600)
    try: fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError: raise Stop('Another US-LA installation is running.')
    return fd

def environment():
    assert_root()
    if not CONFIG.is_file() or CONFIG.is_symlink() or not BIN.is_file() or not MIHOME.is_dir():
        raise Stop('Expected Mihomo binary/config/home missing or config is symlink. Stop.')
    version=cmd([BIN,'-v'],timeout=15).stdout
    if '1.19.33' not in version:
        raise Stop('Expected Mihomo v1.19.33, found '+version.splitlines()[0])
    user=cmd(['systemctl','show',SERVICE,'-p','User','--value']).stdout.strip()
    if not user or user=='root': raise Stop('Require existing non-root Mihomo systemd service.')
    pwd.getpwnam(user)
    if cmd(['systemctl','is-active',SERVICE],check=False).stdout.strip()!='active':
        raise Stop('Mihomo not active; fix existing service before installing nodes.')
    validate(CONFIG,user)
    return user,pwd.getpwnam(user).pw_gid

def validate(path,user):
    res=cmd([BIN,'-t','-d',MIHOME,'-f',path],user=user,check=False,timeout=90)
    if res.returncode:
        # tool may echo secrets on config failure, print bounded generic message only
        raise Stop('Mihomo -t failed (as service user). Check config and logs locally; original untouched when preparing.')

def segments(raw):
    try: lines=raw.decode('utf8').splitlines(keepends=True)
    except UnicodeError: raise Stop('Config not valid UTF-8.')
    heads=[i for i,line in enumerate(lines) if re.match(r'^listeners:\s*(?:#.*)?$',line.rstrip('\r\n'))]
    if len(heads)!=1: raise Stop('Require one multiline root listeners: key; not rewriting unfamiliar YAML.')
    start=heads[0];end=len(lines)
    for k in range(start+1,len(lines)):
        if re.match(r'^[A-Za-z_][\w-]*\s*:',lines[k]):end=k;break
        if lines[k].strip() and not lines[k].startswith((' ','#','\t')):
            raise Stop('Unexpected top-level formatting in listeners section.')
    section=lines[start+1:end]
    indices=[i for i,v in enumerate(section) if re.match(r'^  - name:\s*',v)]
    if not indices: raise Stop('Expected explicit `  - name:` listener items.')
    if re.search(r'(?m)^\s*-\s*type:', ''.join(section)) and len(indices)==0:
        raise Stop('Unknown listener syntax.')
    blocks=[]
    for n,start_i in enumerate(indices):
        end_i=indices[n+1] if n+1<len(indices) else len(section)
        block=''.join(section[start_i:end_i])
        name=re.search(r'^  - name:\s*(\S.+?)\s*$',block,re.M)
        typ=re.search(r'^    type:\s*(\w+)\s*$',block,re.M)
        port=re.search(r'^    port:\s*(\d+)\s*$',block,re.M)
        if not name or not typ or not port:
            raise Stop('Existing listener lacks expected name/type/port; no changes.')
        blocks.append((name.group(1).strip('"\''),typ.group(1).lower(),int(port.group(1))))
    return ''.join(lines[:start+1]),''.join(section),''.join(lines[end:]),blocks

def listener_present(blocks,name,typ,port):
    return (name,typ,port) in blocks

def add_listener(raw,new_lines):
    pre,section,post,blocks=segments(raw)
    if not section.endswith('\n'): section+='\n'
    if not new_lines.startswith('  - name: '): raise Stop('Internal listener template invalid.')
    return (pre+section+new_lines.rstrip('\n')+'\n'+post).encode()

def available(port,udp=False):
    typ=socket.SOCK_DGRAM if udp else socket.SOCK_STREAM
    with socket.socket(socket.AF_INET,typ) as s:
        try:s.bind(('0.0.0.0',port));return True
        except OSError:return False

def listens(port,udp=False):
    flags=['-H','-lun'] if udp else ['-H','-ltn']
    out=cmd(['ss',*flags,f'( sport = :{port} )'],check=False,timeout=10)
    return bool(out.stdout.strip())

def secret_file(dest,data,mode=0o600,gid=None):
    dest=Path(dest)
    dest.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.us-la-',dir=dest.parent)
    try:
        os.fchmod(fd,mode)
        if gid is not None:os.fchown(fd,0,gid)
        with os.fdopen(fd,'wb') as f:
            f.write(data.encode() if isinstance(data,str) else data)
            f.flush();os.fsync(f.fileno())
        os.replace(tmp,dest)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def stage_dir(index):
    if STATE.is_symlink():raise Stop('Rollout directory symlink detected.')
    STATE.mkdir(parents=True,exist_ok=True,mode=0o700)
    os.chmod(STATE,0o700)
    path=STATE/index
    if path.exists():raise Stop('Stage state already exists: '+str(path)+'; no credential regeneration or overwrites.')
    path.mkdir(mode=0o700)
    return path

def temp_verify(candidate,user,gid):
    fd,tmp=tempfile.mkstemp(prefix='.us-la-check-',suffix='.yaml',dir=CONFIG.parent)
    try:
        os.fchown(fd,0,gid);os.fchmod(fd,0o640)
        with os.fdopen(fd,'wb') as f:f.write(candidate)
        validate(Path(tmp),user)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def atomic_live(data,old_stat):
    fd,tmp=tempfile.mkstemp(prefix='.us-la-swap-',dir=CONFIG.parent)
    try:
        os.fchown(fd,old_stat.st_uid,old_stat.st_gid)
        os.fchmod(fd,stat.S_IMODE(old_stat.st_mode))
        with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(tmp,CONFIG)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def restart_check(port,udp=False):
    cmd(['systemctl','restart',SERVICE],timeout=45)
    for _ in range(15):
        if cmd(['systemctl','is-active',SERVICE],check=False).stdout.strip()=='active' and listens(port,udp):return
        time.sleep(.4)
    raise Stop(f'Mihomo did not listen on {port}/{"udp" if udp else "tcp"} after restart.')

def firewall_zone():
    if not shutil.which('firewall-cmd'):return None
    if cmd(['systemctl','is-active','firewalld'],check=False).stdout.strip()!='active':return None
    out=cmd(['firewall-cmd','--get-active-zones']).stdout
    zs=[x.strip().split()[0] for x in out.splitlines() if x and not x[0].isspace()]
    if len(zs)>1:raise Stop('Multiple active firewalld zones; cannot safely choose.')
    zone=zs[0] if zs else cmd(['firewall-cmd','--get-default-zone']).stdout.strip()
    if not re.fullmatch(r'[A-Za-z0-9_-]+',zone):raise Stop('Invalid firewall zone.')
    return zone

def firewall_add(port,proto):
    zone=firewall_zone()
    if not zone:return None
    base=['firewall-cmd','--zone='+zone]
    allow_port=cmd(base+[f'--query-port={port}/{proto}'],check=False).returncode==0
    allow_service=(port==443 and cmd(base+['--query-service=https'],check=False).returncode==0)
    if allow_port or (allow_service and proto=='tcp'):
        return None
    cmd(base+[f'--add-port={port}/{proto}'])
    try:cmd(base+['--permanent',f'--add-port={port}/{proto}'])
    except Exception:
        cmd(base+[f'--remove-port={port}/{proto}'],check=False);raise
    return zone

def firewall_undo(port,proto,zone):
    if not zone or not shutil.which('firewall-cmd'):return
    base=['firewall-cmd','--zone='+zone]
    cmd(base+[f'--remove-port={port}/{proto}'],check=False)
    cmd(base+['--permanent',f'--remove-port={port}/{proto}'],check=False)

def socks_probe(node, *, port, udp=False):
    """Transient Mihomo outbound -> localhost inbound -> remote HTTPS via SOCKS."""
    if not shutil.which('curl'):raise Stop('curl absent; no package installation attempted.')
    user=cmd(['systemctl','show',SERVICE,'-p','User','--value']).stdout.strip()
    acct=pwd.getpwnam(user)
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as s:
        s.bind(('127.0.0.1',0));socksport=s.getsockname()[1]
    node=node.replace('    server: "'+DOMAIN+'"','    server: "127.0.0.1"',1)
    node=node.replace('    sni:', '    servername:',1) # Mihomo outbound uses servername for VLESS
    with tempfile.TemporaryDirectory(prefix='us-la-probe-',dir=MIHOME) as td:
        td=Path(td);os.chown(td,acct.pw_uid,acct.pw_gid);os.chmod(td,0o700)
        test='''socks-port: {port}
allow-lan: false
log-level: error
proxies:
{node}proxy-groups:
  - name: Probe
    type: select
    proxies:
      - {name}
rules:
  - MATCH,Probe
'''.format(port=socksport,node=node,name=q(node_name(node)))
        testfile=td/'test.yaml';testfile.write_text(test)
        os.chown(testfile,acct.pw_uid,acct.pw_gid);os.chmod(testfile,0o600)
        validate(testfile,user)
        def drop():
            os.initgroups(user,acct.pw_gid)
            os.setgid(acct.pw_gid);os.setuid(acct.pw_uid)
        env=os.environ.copy();env['HOME']=str(td)
        proc=subprocess.Popen([str(BIN),'-d',td,'-f',testfile],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,preexec_fn=drop,env=env)
        try:
            for _ in range(45):
                if proc.poll() is not None: raise Stop('Temporary Mihomo client did not start.')
                with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as s:
                    s.settimeout(.2)
                    if s.connect_ex(('127.0.0.1',socksport))==0:break
                time.sleep(.2)
            else:raise Stop('SOCKS probe port unavailable.')
            r=cmd(['curl','--max-time','23','--retry','0','-sS','-o','/dev/null',
                '-w','%{http_code}','--socks5-hostname',f'127.0.0.1:{socksport}',
                'https://example.com/'],check=False,timeout=30)
            if r.returncode or not r.stdout.strip().startswith(('2','3')):
                raise Stop(f'Actual local encrypted proxy HTTP test failed (curl={r.returncode}, http={r.stdout.strip()}).')
        finally:
            proc.terminate()
            try:proc.wait(timeout=3)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()

def node_name(txt):
    m=re.search(r'^  - name:\s*(.+?)\s*$',txt,re.M)
    if not m:raise Stop('Cannot parse node name')
    try:return json.loads(m.group(1))
    except ValueError:return m.group(1)

def save_meta(stage,meta):
    secret_file(stage/'meta.json',json.dumps(meta,indent=2).encode())

def load_meta(stage):
    if not (stage/'meta.json').is_file():raise Stop('No metadata for stage: '+str(stage))
    return json.loads((stage/'meta.json').read_text())

def restore_stage(index):
    assert_root();folder=STATE/index;meta=load_meta(folder)
    if meta['state'] not in ('applied','recovery_needed'):
        raise Stop('Stage is not applied; cannot undo: '+str(meta['state']))
    old=(folder/'old-config.yaml').read_bytes()
    if digest(old)!=meta['before_sha256']:raise Stop('Backup checksum mismatch')
    now=CONFIG.read_bytes()
    if digest(now)!=meta['after_sha256']:
        raise Stop('Current config was subsequently modified; refusing to remove later nodes. Roll back in reverse order.')
    oldstat=CONFIG.stat()
    atomic_live(old,oldstat)
    try: restart_check(meta['previous_main_port'])
    except Exception as exc:
        raise Stop('Restored config written but restart failed: '+str(exc))
    firewall_undo(meta['port'],meta['protocol'],meta.get('firewall_added_zone'))
    meta['state']='rolled_back';save_meta(folder,meta)
    export_stash()
    print('Rollback completed. Backup retained: '+str(folder),flush=True)

def export_stash():
    """Rebuild a full three-node Stash profile from available root-only snippets."""
    sources=[]
    # first stage legacy script has its own private path
    first=STATE/'01'/'stash-node.yaml'
    if first.is_file():
        first_meta=STATE/'01'/'metadata.json'
        if first_meta.is_file() and json.loads(first_meta.read_text()).get('state')=='applied':
            sources.append(first)
    for suffix in ('02','03'):
        f=STATE/suffix/'stash-node.yaml'
        if f.is_file() and load_meta(STATE/suffix).get('state')=='applied':sources.append(f)
    if not sources:return
    snippets=[];names=[]
    for src in sources:
        content=src.read_text()
        if not content.startswith('proxies:\n  - name: '):raise Stop('Unexpected Stash snippet format: '+str(src))
        value=content[len('proxies:\n'):]
        snippets.append(value)
        names.append(node_name(value))
    full='proxies:\n'+''.join(snippets)+'proxy-groups:\n  - name: US-LA\n    type: select\n    proxies:\n'
    full+=''.join('      - '+q(n)+'\n' for n in names)
    full+='      - DIRECT\nrules:\n  - MATCH,US-LA\n'
    secret_file(STATE/'stash-all.yaml',full)
    print('Stash composite profile (root-only): '+str(STATE/'stash-all.yaml'),flush=True)

def deploy(index,name,port,protocol,listener,node,expected,udp=False,preapply=None):
    """Validate / snapshot / swap / restart / real local probe / firewall / final check."""
    lock=acquire()
    folder=None;applied=False;firewall=None
    try:
        tell(1,f'Checking current Mihomo + {name} dependencies...')
        user,gid=environment()
        raw=CONFIG.read_bytes();oldstat=CONFIG.stat()
        _,_,_,blocks=segments(raw)
        if not all(item in blocks for item in expected):
            raise Stop('Prior stages missing. Expected: '+repr(expected)+'; found: '+repr(blocks))
        if name in [n for n,t,p in blocks]:raise Stop('Node already exists; refusing duplicate installation.')
        if not available(port,udp):raise Stop(f'{port}/{protocol} is already bound; not stopping unknown services.')
        tell(1,'Prerequisites and port checks passed.','PASS')
        tell(2,'Creating root-only stage snapshot and generating credentials...')
        folder=stage_dir(index)
        secret_file(folder/'old-config.yaml',raw)
        if preapply:preapply(folder,user,gid)
        new=add_listener(raw,listener)
        secret_file(folder/'candidate.yaml',new)
        secret_file(folder/'stash-node.yaml','proxies:\n'+node)
        meta={'node':name,'port':port,'protocol':protocol,'previous_main_port':443,
              'before_sha256':digest(raw),'after_sha256':digest(new),'state':'prepared',
              'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        save_meta(folder,meta)
        tell(2,'Snapshot stored; credentials do not print to terminal.','PASS')
        tell(3,'Validating new full configuration as non-root Mihomo service user...')
        temp_verify(new,user,gid)
        tell(3,'Candidate configuration accepted.','PASS')
        tell(4,'Applying configuration, while keeping rollback snapshot...')
        if digest(CONFIG.read_bytes())!=digest(raw):raise Stop('Live config changed concurrently; no overwrites.')
        atomic_live(new,oldstat);applied=True
        restart_check(port,udp)
        if not listens(443):raise Stop('Main VLESS TCP 443 no longer listening.')
        tell(4,f'{name} now listens on {port}/{protocol}; main VLESS still active.','PASS')
        tell(5,'Testing a real local encrypted proxy connection over HTTPS...')
        socks_probe(node,port=port,udp=udp)
        tell(5,'End-to-end proxy test completed successfully.','PASS')
        tell(6,'Checking active host firewall and opening only required port if needed...')
        firewall=firewall_add(port,protocol)
        meta['firewall_added_zone']=firewall
        save_meta(folder,meta)
        tell(6,'Host firewall stage complete. Provider firewall is not controlled.','PASS')
        tell(7,'Re-checking service and candidate checksum...')
        if cmd(['systemctl','is-active',SERVICE],check=False).stdout.strip()!='active' or not listens(port,udp) or not listens(443):
            raise Stop('Final service or listening socket check failed.')
        if digest(CONFIG.read_bytes())!=digest(new):raise Stop('Live configuration changed unexpectedly.')
        validate(CONFIG,user)
        tell(7,'All local server checks passed.','PASS')
        meta['state']='applied';save_meta(folder,meta)
        tell(8,'Exporting updated Stash client profiles...')
        export_stash()
        tell(8,f'COMPLETE: {name}; still verify from Stash over public network.','PASS')
        return True
    except Exception as exc:
        print('[STOP] '+str(exc),flush=True)
        if applied:
            print('[ROLLBACK] Restoring configuration before this stage...',flush=True)
            try:
                folder_meta=load_meta(folder) if folder else {}
                original=(folder/'old-config.yaml').read_bytes()
                if digest(CONFIG.read_bytes())==folder_meta['after_sha256']:
                    atomic_live(original,oldstat)
                    restart_check(443)
                    firewall_undo(port,protocol,firewall)
                    folder_meta['state']='failed_reverted';save_meta(folder,folder_meta)
                    print('[ROLLBACK] Original nodes restored.',flush=True)
                else:
                    print('[ROLLBACK WARNING] Config changed externally; preserved backup in '+str(folder),flush=True)
            except Exception as subexc:
                print('[ROLLBACK FAILED] '+str(subexc)+'; backup exists at '+str(folder),flush=True)
        raise
    finally:
        os.close(lock)
